//+------------------------------------------------------------------+
//|  TradingJournal_Complete.mq5                                     |
//|  Copyright 2024, JR369 HOLDINGS                                  |
//|  https://hopiplaka.gumroad.com                                   |
//+------------------------------------------------------------------+
//  Arquivo principal — apenas orquestração                         |
//  Toda a lógica está nos arquivos .mqh da pasta Golden Bullet      |
//  v4.10 — Operar pelo painel: ordens, lote por risco e parciais   |
//+------------------------------------------------------------------+
#property copyright "Copyright 2024, JR369 HOLDINGS"
#property link      "https://hopiplaka.gumroad.com"
#property version   "4.10"
#property strict

//-------------------------------------------------------------------
// INCLUDES — ordem importa: Config primeiro, depois dependentes
//-------------------------------------------------------------------
#include <Golden Bullet\TJ_Config.mqh>
#include <Golden Bullet\TJ_HTTP.mqh>
#include <Golden Bullet\TJ_Cache.mqh>
#include <Golden Bullet\TradingJournalStats.mqh>
#include <Golden Bullet\TJ_Stats.mqh>
#include <Golden Bullet\TJ_Export.mqh>
#include <Golden Bullet\TJ_Trade.mqh>

//+------------------------------------------------------------------+
//| OnInit                                                           |
//+------------------------------------------------------------------+
int OnInit()
{
    Print("=== TradingJournal Complete v4.10 (Convex) ===");

    if(ConvexUrl(DEALS_PATH) == "")
    {
        Print("ERRO: cole em InpUrl o URL do webhook MT5 (Diario > Conector no painel).");
        return INIT_PARAMETERS_INCORRECT;
    }

    G_EaStart = TimeCurrent();
    // 250 ms: parciais automáticas e sync com o painel (que define o ritmo)
    EventSetMillisecondTimer(250);
    InitTrade();

    if(InpExportMode != MODE_DISABLED)
        InitExporter();
    else
        RunStatsSync();

    return INIT_SUCCEEDED;
}

void OnDeinit(const int reason)
{
    EventKillTimer();
    SavePlans();
}

//+------------------------------------------------------------------+
//| Tempo real: cada negócio novo da conta (manual, EA ou copiador) |
//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest &request,
                        const MqlTradeResult &result)
{
    if(InpExportMode == MODE_DISABLED) return;
    if(trans.type != TRADE_TRANSACTION_DEAL_ADD) return;
    OnDealAdded(trans.deal);
}

//+------------------------------------------------------------------+
//| OnTimer (250 ms): parciais, sync com o painel, fila de reenvio  |
//| e estatísticas periódicas                                        |
//+------------------------------------------------------------------+
void OnTimer()
{
    CheckPlans();
    RunTradeSync();

    static ulong lastRetry = 0;
    if(GetTickCount64() - lastRetry >= (ulong)MathMax(5, InpRetrySeconds) * 1000)
    {
        RetryPending();
        lastRetry = GetTickCount64();
    }

    if(InpStatsMinutes > 0)
    {
        static datetime lastStats = 0;
        if(TimeCurrent() - lastStats >= InpStatsMinutes * 60)
        {
            RunStatsSync();
            lastStats = TimeCurrent();
        }
    }
}
