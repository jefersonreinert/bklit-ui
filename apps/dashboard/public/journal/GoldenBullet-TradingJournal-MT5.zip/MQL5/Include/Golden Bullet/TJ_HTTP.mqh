//+------------------------------------------------------------------+
//|  TJ_HTTP.mqh — HTTP Helpers + JSON / Formato Helpers            |
//|  Parte do TradingJournal Complete v4.00 (Convex)                          |
//+------------------------------------------------------------------+
#ifndef TJ_HTTP_MQH
#define TJ_HTTP_MQH

//====================================================================
//  HTTP HELPERS — Convex
//  InpUrl é o URL do webhook MT5 copiado do painel:
//    https://<deployment>.convex.site/journal/mt5?token=...
//  Outras rotas trocam só o caminho e mantêm o token.
//====================================================================
string ConvexUrl(string path)
{
    string url = InpUrl;
    StringTrimLeft(url); StringTrimRight(url);
    int p = StringFind(url, DEALS_PATH);
    if(p < 0) return "";
    return StringSubstr(url, 0, p) + path + StringSubstr(url, p + StringLen(DEALS_PATH));
}

void StringToBytes(const string s, char &out[])
{
    int n = StringToCharArray(s, out, 0, WHOLE_ARRAY, CP_UTF8);
    if(n > 0) ArrayResize(out, n - 1);
}

// Devolve o corpo da resposta, ou "" se falhar.
string ConvexPost(string path, string body)
{
    string url = ConvexUrl(path);
    if(url == "") { Print("[HTTP] InpUrl invalido: cole o URL do webhook MT5 do painel"); return ""; }
    char data[], result[];
    string resH;
    StringToBytes(body, data);
    ResetLastError();
    int code = WebRequest("POST", url, "Content-Type: application/json\r\n", 10000, data, result, resH);
    string resp = CharArrayToString(result, 0, WHOLE_ARRAY, CP_UTF8);
    if(code == 200) return resp;
    if(code == -1)
        PrintFormat("[HTTP] WebRequest falhou (erro %d). Permita o URL em Ferramentas > Opcoes > Expert Advisors.", GetLastError());
    else
        PrintFormat("[HTTP] POST %s -> %d | %s", path, code, StringSubstr(resp, 0, 300));
    return "";
}

//====================================================================
//  JSON HELPERS
//====================================================================
string JsonGet(string json, string key)
{
    string s = "\"" + key + "\":\"";
    int p = StringFind(json, s);
    if(p < 0) return "";
    p += StringLen(s);
    int e = StringFind(json, "\"", p);
    if(e < 0) return "";
    return StringSubstr(json, p, e - p);
}

string JsonGetAfter(string json, string anchor, string key)
{
    int ap = StringFind(json, anchor);
    if(ap < 0) return "";
    return JsonGet(StringSubstr(json, ap), key);
}

// JSON escape
string JE(string s)
{
    StringReplace(s, "\\", "\\\\");
    StringReplace(s, "\"", "\\\"");
    StringReplace(s, "\n", " ");
    StringReplace(s, "\r", "");
    StringReplace(s, "\t", " ");
    return s;
}

//====================================================================
//  FORMATO / CONVERSÃO HELPERS
//====================================================================
string DateTimeToISO(datetime t)
{
    MqlDateTime dt; TimeToStruct(t, dt);
    return StringFormat("%04d-%02d-%02dT%02d:%02d:%02dZ",
                        dt.year, dt.mon, dt.day, dt.hour, dt.min, dt.sec);
}

string DurationToStr(int sec)
{
    return StringFormat("%02d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60);
}

string WeekdayName(int dow)
{
    string n[] = {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
    return (dow >= 0 && dow <= 6) ? n[dow] : "";
}

string MonthName(int mon)
{
    string n[] = {"","January","February","March","April","May","June",
                     "July","August","September","October","November","December"};
    return (mon >= 1 && mon <= 12) ? n[mon] : "";
}

string AccountTypeName(ACCOUNT_TYPE t)
{
    switch(t)
    {
        case ACCOUNT_PERSONAL:       return "Personal";
        case ACCOUNT_BACKTESTING:    return "Back-Testing";
        case ACCOUNT_PROP_VALUATION: return "Prop-Valuation";
        case ACCOUNT_PROP_FUNDING:   return "Prop-Funding";
    }
    return "Personal";
}

string NormalizeSymbol(string symbol)
{
    StringToUpper(symbol);
    string suffixes[] = {".RAW",".I","PRO","MICRO","."};
    for(int i = 0; i < ArraySize(suffixes); i++)
    {
        int p = StringFind(symbol, suffixes[i]);
        if(p > 4) { symbol = StringSubstr(symbol, 0, p); break; }
    }
    if(symbol == "XAUUSD" || symbol == "GOLD")  return "XAUUSD";
    if(symbol == "XAGUSD" || symbol == "SILVER") return "XAGUSD";
    if(symbol == "US30"   || symbol == "DJ30")   return "DJI";
    if(symbol == "US500"  || symbol == "SPX")    return "SPX500";
    if(symbol == "US100"  || symbol == "NDX")    return "NAS100";
    if(symbol == "GER40"  || symbol == "GER30")  return "DAX";
    if(symbol == "USOIL"  || symbol == "OIL")    return "CRUDE OIL";
    if(symbol == "BTCUSD")                        return "BTC";
    if(symbol == "ETHUSD")                        return "ETH";
    return symbol;
}

string DetermineMarketName(string symbol)
{
    StringToUpper(symbol);
    if(StringFind(symbol,"BTC")>=0||StringFind(symbol,"ETH")>=0||
       StringFind(symbol,"XRP")>=0||StringFind(symbol,"LTC")>=0)
        return "Cryptocurrencies";
    if(StringFind(symbol,"XAU")>=0||StringFind(symbol,"XAG")>=0||
       StringFind(symbol,"OIL")>=0||StringFind(symbol,"GOLD")>=0)
        return "Commodities";
    if(StringFind(symbol,"NAS")>=0||StringFind(symbol,"NDX")>=0||
       StringFind(symbol,"SPX")>=0||StringFind(symbol,"US5")>=0||
       StringFind(symbol,"US30")>=0||StringFind(symbol,"DJ")>=0||
       StringFind(symbol,"DAX")>=0||StringFind(symbol,"GER")>=0||
       StringFind(symbol,"100")>=0||StringFind(symbol,"500")>=0)
        return "Equities";
    return "Forex";
}

double CalcRiskDollars(string symbol, double volume, double openPrice, double sl)
{
    if(sl == 0.0 || openPrice == 0.0 || volume == 0.0) return 0.0;
    double tickSize  = SymbolInfoDouble(symbol, SYMBOL_TRADE_TICK_SIZE);
    double tickValue = SymbolInfoDouble(symbol, SYMBOL_TRADE_TICK_VALUE);
    if(tickSize <= 0.0) return 0.0;
    return (MathAbs(openPrice - sl) / tickSize) * tickValue * volume;
}

#endif // TJ_HTTP_MQH
