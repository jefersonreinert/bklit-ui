//+------------------------------------------------------------------+
//|  TJ_Export.mqh — Exportação de Negócios para o Convex           |
//|  Parte do TradingJournal Complete v4.00 (Convex)                 |
//|                                                                  |
//|  O painel agrupa os negócios por posição para montar cada trade, |
//|  por isso enviamos as entradas E as saídas. Os cálculos do EA    |
//|  (R:R, risco, pontos, duração, resultado, snapshot da conta)     |
//|  seguem como campos extra no negócio de saída.                   |
//|  O servidor grava cada (conta, ticket) uma só vez.               |
//+------------------------------------------------------------------+
#ifndef TJ_EXPORT_MQH
#define TJ_EXPORT_MQH

//====================================================================
//  INICIALIZAR EXPORTADOR (chamado no OnInit)
//====================================================================
void InitExporter()
{
    if(InpAvoidDups) LoadSentTickets();

    if(InpExportMode == MODE_ALL_HISTORY)
    {
        Print("[Export] Modo: TODO O HISTORICO + tempo real");
        ExportHistory(0, TimeCurrent() + 86400);
    }
    else if(InpExportMode == MODE_FROM_DATE)
    {
        PrintFormat("[Export] Modo: A PARTIR DE %s + tempo real", TimeToString(InpFromDate));
        ExportHistory(InpFromDate, TimeCurrent() + 86400);
    }
    else
        Print("[Export] Modo: TEMPO REAL — aguardando operacoes...");
}

//====================================================================
//  FILTROS
//====================================================================
bool IsTradeDeal(ulong ticket)
{
    ENUM_DEAL_TYPE t = (ENUM_DEAL_TYPE)HistoryDealGetInteger(ticket, DEAL_TYPE);
    return t == DEAL_TYPE_BUY || t == DEAL_TYPE_SELL;
}

bool IsExitDeal(ulong ticket)
{
    ENUM_DEAL_ENTRY e = (ENUM_DEAL_ENTRY)HistoryDealGetInteger(ticket, DEAL_ENTRY);
    return e == DEAL_ENTRY_OUT || e == DEAL_ENTRY_OUT_BY || e == DEAL_ENTRY_INOUT;
}

string EntryName(ENUM_DEAL_ENTRY e)
{
    switch(e)
    {
        case DEAL_ENTRY_IN:     return "in";
        case DEAL_ENTRY_OUT:    return "out";
        case DEAL_ENTRY_INOUT:  return "inout";
        case DEAL_ENTRY_OUT_BY: return "out_by";
    }
    return "";
}

//====================================================================
//  JSON DE UM NEGÓCIO
//  Requer que o negócio esteja na seleção de histórico atual.
//====================================================================
string DealJson(ulong ticket)
{
    string   symbol     = HistoryDealGetString(ticket,  DEAL_SYMBOL);
    int      digits     = (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS);
    if(digits <= 0) digits = 5;
    ENUM_DEAL_TYPE  dtype = (ENUM_DEAL_TYPE) HistoryDealGetInteger(ticket, DEAL_TYPE);
    ENUM_DEAL_ENTRY entry = (ENUM_DEAL_ENTRY)HistoryDealGetInteger(ticket, DEAL_ENTRY);
    ulong    positionId = HistoryDealGetInteger(ticket, DEAL_POSITION_ID);
    double   price      = HistoryDealGetDouble(ticket, DEAL_PRICE);
    double   volume     = HistoryDealGetDouble(ticket, DEAL_VOLUME);
    double   sl         = HistoryDealGetDouble(ticket, DEAL_SL);
    double   tp         = HistoryDealGetDouble(ticket, DEAL_TP);
    double   profit     = HistoryDealGetDouble(ticket, DEAL_PROFIT);
    double   commission = HistoryDealGetDouble(ticket, DEAL_COMMISSION);
    double   swap       = HistoryDealGetDouble(ticket, DEAL_SWAP);
    double   fee        = HistoryDealGetDouble(ticket, DEAL_FEE);

    string j = "{";
    j += "\"account\":\""  + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "\",";
    j += "\"ticket\":\""   + IntegerToString(ticket)     + "\",";
    j += "\"position\":\"" + IntegerToString(positionId) + "\",";
    j += "\"symbol\":\""   + JE(symbol) + "\",";
    j += "\"type\":\""     + (dtype == DEAL_TYPE_BUY ? "buy" : "sell") + "\",";
    j += "\"entry\":\""    + EntryName(entry) + "\",";
    j += "\"volume\":"     + DoubleToString(volume, 2)      + ",";
    j += "\"price\":"      + DoubleToString(price, digits)  + ",";
    j += "\"sl\":"         + DoubleToString(sl, digits)     + ",";
    j += "\"tp\":"         + DoubleToString(tp, digits)     + ",";
    j += "\"profit\":"     + DoubleToString(profit, 2)      + ",";
    j += "\"commission\":" + DoubleToString(commission, 2)  + ",";
    j += "\"swap\":"       + DoubleToString(swap, 2)        + ",";
    j += "\"fee\":"        + DoubleToString(fee, 2)         + ",";
    j += "\"magic\":"      + IntegerToString(HistoryDealGetInteger(ticket, DEAL_MAGIC)) + ",";
    j += "\"comment\":\""  + JE(HistoryDealGetString(ticket, DEAL_COMMENT)) + "\",";
    j += "\"time_msc\":"   + IntegerToString(HistoryDealGetInteger(ticket, DEAL_TIME_MSC));

    if(IsExitDeal(ticket))
        j += ExitExtrasJson(ticket, symbol, positionId, price, volume, sl, tp,
                            profit, commission, swap, fee);
    j += "}";
    return j;
}

//====================================================================
//  CAMPOS EXTRA DO NEGÓCIO DE SAÍDA (cálculos do v3.05)
//====================================================================
string ExitExtrasJson(ulong closeTicket, string symbol, ulong positionId,
                      double closePrice, double volume, double sl, double tp,
                      double profit, double commission, double swap, double fee)
{
    datetime closeTime = (datetime)HistoryDealGetInteger(closeTicket, DEAL_TIME);

    // Negócio de entrada da mesma posição (preço, hora e comissão de entrada)
    double   openPrice = closePrice;
    datetime openTime  = closeTime;
    double   openComm  = 0.0;
    int total = HistoryDealsTotal();
    for(int i = 0; i < total; i++)
    {
        ulong tk = HistoryDealGetTicket(i);
        if(tk <= 0) continue;
        if(HistoryDealGetInteger(tk, DEAL_POSITION_ID) == (long)positionId &&
           (ENUM_DEAL_ENTRY)HistoryDealGetInteger(tk, DEAL_ENTRY) == DEAL_ENTRY_IN)
        {
            openPrice = HistoryDealGetDouble(tk, DEAL_PRICE);
            openTime  = (datetime)HistoryDealGetInteger(tk, DEAL_TIME);
            openComm  = HistoryDealGetDouble(tk, DEAL_COMMISSION);
            break;
        }
    }

    double tickSize  = SymbolInfoDouble(symbol, SYMBOL_TRADE_TICK_SIZE);
    double pointSize = SymbolInfoDouble(symbol, SYMBOL_POINT);
    // Comissão real de ida e volta (antes: saída × 2)
    double netPnL    = profit + commission + openComm + swap + fee;

    double rr = 0.0;
    if(sl != 0.0 && tp != 0.0)
    {
        double risk   = MathAbs(openPrice - sl);
        double reward = MathAbs(tp - openPrice);
        if(risk > 0.0) rr = reward / risk;
    }

    double riskDollars = CalcRiskDollars(symbol, volume, openPrice, sl);
    double balance     = AccountInfoDouble(ACCOUNT_BALANCE);
    double riskPct     = (balance > 0.0) ? (riskDollars / balance) : 0.0;

    int profitPoints = 0;
    if(tickSize > 0.0 && pointSize > 0.0 && volume > 0.0)
        profitPoints = (int)MathRound(profit / (volume * tickSize / pointSize));

    string outcome = (netPnL >  0.01) ? "win"  :
                     (netPnL < -0.01) ? "loss" : "breakeven";

    string j = "";
    if(InpSendRR && rr > 0)    j += ",\"rr\":"            + DoubleToString(rr, 2);
    if(InpSendRiskPct)         j += ",\"risk_pct\":"      + DoubleToString(riskPct, 6);
    if(InpSendRiskDlr)         j += ",\"risk_usd\":"      + DoubleToString(riskDollars, 2);
    if(InpSendProfitPts)       j += ",\"profit_points\":" + IntegerToString(profitPoints);
    if(InpSendDuration)        j += ",\"duration_sec\":"  + IntegerToString((int)(closeTime - openTime));
    if(InpSendOutcome)         j += ",\"outcome\":\""     + outcome + "\"";
    if(InpSendAccountEquity)   j += ",\"equity\":"        + DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY), 2);
    if(InpSendAccountBal)      j += ",\"balance\":"       + DoubleToString(balance, 2);
    j += ",\"account_type\":\"" + AccountTypeName(InpAccountType) + "\"";
    j += ",\"market\":\""       + DetermineMarketName(symbol) + "\"";
    return j;
}

//====================================================================
//  ENVIO EM LOTE
//====================================================================
string BatchBody(string &items[], int count)
{
    string b = "{";
    b += "\"account\":\"" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "\",";
    b += "\"server\":\""  + JE(AccountInfoString(ACCOUNT_SERVER))  + "\",";
    b += "\"name\":\""    + JE(AccountInfoString(ACCOUNT_COMPANY)) + "\",";
    b += "\"deals\":[";
    for(int i = 0; i < count; i++)
    {
        if(i > 0) b += ",";
        b += items[i];
    }
    b += "]}";
    return b;
}

// Envia os negócios (já na seleção de histórico). Falhas vão para a fila.
bool SendDeals(ulong &tickets[])
{
    int n = ArraySize(tickets);
    if(n == 0) return true;
    string items[];
    ArrayResize(items, n);
    for(int i = 0; i < n; i++) items[i] = DealJson(tickets[i]);

    if(ConvexPost(DEALS_PATH, BatchBody(items, n)) != "")
    {
        if(InpAvoidDups) MarkAsSent(tickets);
        return true;
    }
    for(int i = 0; i < n; i++) QueueRetry(tickets[i]);
    return false;
}

void QueueRetry(ulong ticket)
{
    int n = ArraySize(G_RetryTickets);
    for(int i = 0; i < n; i++)
        if(G_RetryTickets[i] == ticket) return;
    ArrayResize(G_RetryTickets, n + 1);
    G_RetryTickets[n] = ticket;
}

//====================================================================
//  EXPORTAR HISTÓRICO
//====================================================================
void ExportHistory(datetime from, datetime to)
{
    if(!HistorySelect(from, to)) { Print("[Export] ERRO: HistorySelect falhou"); return; }
    int total = HistoryDealsTotal();
    int exported = 0, skipped = 0, failed = 0;
    PrintFormat("[Export] Processando %d deals...", total);

    ulong batch[];
    for(int i = 0; i < total && !IsStopped(); i++)
    {
        ulong ticket = HistoryDealGetTicket(i);
        if(ticket <= 0 || !IsTradeDeal(ticket)) continue;
        if(InpAvoidDups && IsAlreadySent(ticket)) { skipped++; continue; }

        int n = ArraySize(batch);
        ArrayResize(batch, n + 1);
        batch[n] = ticket;
        if(n + 1 >= MAX_BATCH)
        {
            if(SendDeals(batch)) exported += n + 1; else failed += n + 1;
            ArrayFree(batch);
        }
    }
    int rest = ArraySize(batch);
    if(rest > 0) { if(SendDeals(batch)) exported += rest; else failed += rest; }

    PrintFormat("[Export] Concluido | Enviados=%d | Ja enviados=%d | Na fila=%d",
                exported, skipped, failed);
    if(exported > 0) RunStatsSync();
}

//====================================================================
//  TEMPO REAL (chamado em OnTradeTransaction)
//  Apanha também fechos parciais e trades de outros EAs.
//====================================================================
void OnDealAdded(ulong ticket)
{
    if(!HistoryDealSelect(ticket)) { QueueRetry(ticket); return; }
    if(!IsTradeDeal(ticket)) return;
    // DealJson procura a entrada da posição na seleção atual
    ulong positionId = HistoryDealGetInteger(ticket, DEAL_POSITION_ID);
    HistorySelectByPosition(positionId);

    ulong one[1]; one[0] = ticket;
    bool exit = IsExitDeal(ticket);
    if(SendDeals(one))
        PrintFormat("[Export] %s %s #%I64u enviado",
                    exit ? "Saida" : "Entrada",
                    HistoryDealGetString(ticket, DEAL_SYMBOL), positionId);
    if(exit) RunStatsSync();
}

//====================================================================
//  REENVIO DA FILA (chamado no OnTimer)
//====================================================================
void RetryPending()
{
    int n = ArraySize(G_RetryTickets);
    if(n == 0) return;
    ulong pending[];
    ArrayCopy(pending, G_RetryTickets);
    ArrayFree(G_RetryTickets);

    if(!HistorySelect(0, TimeCurrent() + 86400)) { ArrayCopy(G_RetryTickets, pending); return; }
    for(int start = 0; start < n; start += MAX_BATCH)
    {
        ulong batch[];
        ArrayCopy(batch, pending, 0, start, MathMin(MAX_BATCH, n - start));
        SendDeals(batch);
    }
    if(ArraySize(G_RetryTickets) == 0)
        PrintFormat("[Export] Fila reenviada (%d negocios)", n);
}

#endif // TJ_EXPORT_MQH
