//+------------------------------------------------------------------+
//|  TJ_Config.mqh — Defines, Enums, Inputs e Variáveis Globais     |
//|  Parte do TradingJournal Complete v4.10 (Convex)                 |
//+------------------------------------------------------------------+
#ifndef TJ_CONFIG_MQH
#define TJ_CONFIG_MQH

//-------------------------------------------------------------------
// CONVEX CONFIG
//-------------------------------------------------------------------
#define DEALS_PATH     "/journal/mt5"
#define STATS_PATH     "/journal/mt5/stats"
#define SYNC_PATH      "/journal/mt5/sync"
#define PLANS_FILE     "TradingJournal_Partials.csv"
#define SENT_FILE      "TradingJournal_SentTickets.txt"
#define MAX_BATCH      100    // limite do servidor: 500 negócios por pedido

//-------------------------------------------------------------------
// ENUMS
//-------------------------------------------------------------------
enum EXPORT_MODE
{
    MODE_DISABLED,      // Desativado
    MODE_ALL_HISTORY,   // Todo o histórico + tempo real
    MODE_FROM_DATE,     // A partir de uma data + tempo real
    MODE_ON_CLOSE       // Só tempo real (a partir de agora)
};

enum ACCOUNT_TYPE
{
    ACCOUNT_PERSONAL,
    ACCOUNT_BACKTESTING,
    ACCOUNT_PROP_VALUATION,
    ACCOUNT_PROP_FUNDING
};

//-------------------------------------------------------------------
// INPUTS
//-------------------------------------------------------------------
input group "=== CONVEX (DIARIO DO PAINEL) ==="
input string InpUrl          = "";   // URL do webhook MT5 (Diario > Conector), com ?token=
input int    InpRetrySeconds = 15;   // Reenvio de falhas (segundos)

input group "=== EXPORTACAO DE TRADES ==="
input EXPORT_MODE  InpExportMode  = MODE_ALL_HISTORY;
input datetime     InpFromDate    = D'2024.01.01 00:00';
input ACCOUNT_TYPE InpAccountType = ACCOUNT_PERSONAL;
input bool         InpAvoidDups   = false;  // true = nao reenviar (o painel ja ignora duplicados)

input group "=== STATISTICS SYNC ==="
input double InpMonthlyTargetPct = 10.0;
input double InpWeeklyTargetPct  =  2.5;
input int    InpStatsMinutes     =  5;   // Enviar estatisticas a cada N minutos (0 = so apos trades)

input group "=== OPERAR PELO PAINEL (v4.10) ==="
input bool   InpAllowTrading     = false;  // Aceitar ordens enviadas pelo painel
input double InpMaxLot           = 1.0;    // Lote maximo por ordem
input double InpMaxRiskPct       = 2.0;    // Risco maximo por ordem (% do saldo)
input bool   InpDemoOnly         = true;   // So executar em conta demo
input bool   InpRequireSL        = true;   // Exigir stop loss
input int    InpCommandMaxAgeSec = 10;     // Descartar ordens com mais de N segundos
input long   InpMagic            = 369369; // Magic das ordens do painel
input int    InpSlippagePoints   = 20;     // Desvio maximo (pontos)

input group "=== CAMPOS EXTRA (NO NEGOCIO DE SAIDA) ==="
input bool InpSendRR            = true;
input bool InpSendRiskPct       = true;
input bool InpSendRiskDlr       = true;
input bool InpSendDuration      = true;
input bool InpSendOutcome       = true;
input bool InpSendProfitPts     = true;
input bool InpSendAccountEquity = true;
input bool InpSendAccountBal    = true;

//-------------------------------------------------------------------
// Controle de exportação
//-------------------------------------------------------------------
ulong    G_SentTickets[];
ulong    G_RetryTickets[];   // negócios cujo envio falhou
ulong    G_RecentTickets[];  // últimos enviados em tempo real (o MT5 pode repetir o DEAL_ADD)
datetime G_EaStart = 0;

#endif // TJ_CONFIG_MQH
