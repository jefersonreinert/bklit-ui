//+------------------------------------------------------------------+
//|  TJ_Cache.mqh — Controle de Duplicatas                            |
//|  Parte do TradingJournal Complete v4.00 (Convex)                          |
//+------------------------------------------------------------------+
#ifndef TJ_CACHE_MQH
#define TJ_CACHE_MQH

//====================================================================
//  CONTROLE DE DUPLICATAS — arquivo de tickets já enviados
//====================================================================
void LoadSentTickets()
{
    if(!FileIsExist(SENT_FILE)) return;
    int h = FileOpen(SENT_FILE, FILE_READ | FILE_TXT | FILE_ANSI);
    if(h == INVALID_HANDLE) return;
    int count = 0;
    while(!FileIsEnding(h))
    {
        string line = FileReadString(h);
        if(StringLen(line) > 0)
        {
            ArrayResize(G_SentTickets, count + 1);
            G_SentTickets[count++] = (ulong)StringToInteger(line);
        }
    }
    FileClose(h);
    PrintFormat("[Export] %d tickets ja enviados carregados.", count);
}

bool IsAlreadySent(ulong ticket)
{
    int n = ArraySize(G_SentTickets);
    for(int i = 0; i < n; i++)
        if(G_SentTickets[i] == ticket) return true;
    return false;
}

void MarkAsSent(ulong &tickets[])
{
    int add = ArraySize(tickets);
    if(add == 0) return;
    int n = ArraySize(G_SentTickets);
    ArrayResize(G_SentTickets, n + add);
    for(int i = 0; i < add; i++) G_SentTickets[n + i] = tickets[i];
    int h = FileOpen(SENT_FILE, FILE_WRITE | FILE_READ | FILE_TXT | FILE_ANSI);
    if(h == INVALID_HANDLE) return;
    FileSeek(h, 0, SEEK_END);
    for(int i = 0; i < add; i++) FileWriteString(h, IntegerToString(tickets[i]) + "\n");
    FileClose(h);
}

void ResetSentTickets()
{
    FileDelete(SENT_FILE);
    ArrayFree(G_SentTickets);
}

#endif // TJ_CACHE_MQH
