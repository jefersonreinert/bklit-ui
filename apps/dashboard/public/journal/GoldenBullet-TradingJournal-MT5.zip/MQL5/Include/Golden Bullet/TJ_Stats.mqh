//+------------------------------------------------------------------+
//|  TJ_Stats.mqh — Statistics Sync to Convex                        |
//|  Parte do TradingJournal Complete v4.00 (Convex)                 |
//|                                                                  |
//|  Logica:                                                         |
//|    1. Stats_Calculate() (TradingJournalStats.mqh) calcula tudo.  |
//|    2. PushStatsToConvex() envia um snapshot por conta para       |
//|       POST /journal/mt5/stats (o servidor guarda o último).      |
//|    3. RunStatsSync() — chamado após cada saída, após o           |
//|       histórico e a cada InpStatsMinutes no OnTimer.             |
//+------------------------------------------------------------------+
#ifndef TJ_STATS_MQH
#define TJ_STATS_MQH

string NumField(string key, double v, int digits)
{
    return "\"" + key + "\":" + DoubleToString(NormalizeDouble(v, digits), digits) + ",";
}

string IntField(string key, long v)
{
    return "\"" + key + "\":" + IntegerToString(v) + ",";
}

bool PushStatsToConvex(SAccountStats &s, double weeklyTargetPct, double monthlyTargetPct)
{
    string b = "{";
    b += "\"account\":\""      + JE(s.accountNumber) + "\",";
    b += "\"server\":\""       + JE(s.serverName)    + "\",";
    b += "\"name\":\""         + JE(s.companyName)   + "\",";
    b += "\"holder\":\""       + JE(s.accountName)   + "\",";
    b += "\"currency\":\""     + JE(s.currency)      + "\",";
    b += "\"account_type\":\"" + AccountTypeName(InpAccountType) + "\",";
    b += "\"time\":"           + IntegerToString((long)TimeCurrent()) + ",";
    b += "\"stats\":{";

    // --- Balanco / Equity ---
    b += NumField("balance",        s.balance,        2);
    b += NumField("equity",         s.equity,         2);
    b += NumField("freeMargin",     s.freeMargin,     2);
    b += NumField("initialDeposit", s.initialDeposit, 2);
    b += NumField("withdrawal",     s.withdrawal,     2);

    // --- PnL ---
    b += NumField("grossProfit",     s.grossProfit,     2);
    b += NumField("grossLoss",       s.grossLoss,       2);
    b += NumField("netProfit",       s.netProfit,       2);
    b += NumField("totalCommission", s.totalCommission, 2);
    b += NumField("totalSwap",       s.totalSwap,       2);
    b += NumField("dailyProfit",     s.dailyProfit,     2);
    b += NumField("weeklyProfit",    s.weeklyProfit,    2);
    b += NumField("monthlyProfit",   s.monthlyProfit,   2);
    b += NumField("maxProfitTrade",  s.maxProfitTrade,  2);
    b += NumField("maxLossTrade",    s.maxLossTrade,    2);

    // --- Targets ---
    b += NumField("startingWeeklyEquity",  s.startingWeeklyEquity,  2);
    b += NumField("startingMonthlyEquity", s.startingMonthlyEquity, 2);
    b += NumField("weeklyTarget",          s.weeklyTarget,          2);
    b += NumField("monthlyTarget",         s.monthlyTarget,         2);
    b += NumField("weeklyTargetPct",       weeklyTargetPct  / 100.0, 6);
    b += NumField("monthlyTargetPct",      monthlyTargetPct / 100.0, 6);
    b += NumField("weeklyTargetProgress",  s.weeklyTargetProgress,  6);
    b += NumField("monthlyTargetProgress", s.monthlyTargetProgress, 6);
    b += NumField("targetPercent",         s.targetPercent,         6);

    // --- Ratios / Drawdown ---
    b += NumField("winRate",        s.winRate,        6);
    b += NumField("profitFactor",   s.profitFactor,   4);
    b += NumField("recoveryFactor", s.recoveryFactor, 4);
    b += NumField("sharpeRatio",    s.sharpeRatio,    4);
    b += NumField("expectedPayoff", s.expectedPayoff, 2);
    b += NumField("dailyDrawdown",  s.dailyDrawdown,  6);

    // --- Contagens ---
    b += IntField("totalTrades",        s.totalTrades);
    b += IntField("profitTrades",       s.profitTrades);
    b += IntField("lossTrades",         s.lossTrades);
    b += IntField("longTrades",         s.longTrades);
    b += IntField("shortTrades",        s.shortTrades);
    b += IntField("maxConWins",         s.maxConWins);
    b += IntField("maxConLosses",       s.maxConLosses);
    b += IntField("maxConProfitTrades", s.maxConProfitTrades);

    // Remover vírgula final
    int bLen = StringLen(b);
    if(StringGetCharacter(b, bLen - 1) == ',')
        b = StringSubstr(b, 0, bLen - 1);
    b += "}}";

    return ConvexPost(STATS_PATH, b) != "";
}

//====================================================================
//  MAIN ENTRY POINT — RunStatsSync()
//====================================================================
void RunStatsSync()
{
    SAccountStats s;
    ZeroMemory(s);
    double equity         = AccountInfoDouble(ACCOUNT_EQUITY);
    double weeklyTargetV  = equity * (InpWeeklyTargetPct  / 100.0);
    double monthlyTargetV = equity * (InpMonthlyTargetPct / 100.0);

    if(!Stats_Calculate(s, InpMonthlyTargetPct, weeklyTargetV, monthlyTargetV))
    {
        Print("[Stats] FALHA em Stats_Calculate — abortando sync");
        return;
    }

    if(PushStatsToConvex(s, InpWeeklyTargetPct, InpMonthlyTargetPct))
        PrintFormat("[Stats] Sincronizado | Trades=%d | WinRate=%.1f%% | NetPnL=%.2f",
                    s.totalTrades, s.winRate * 100.0, s.netProfit);
    else
        Print("[Stats] FALHA ao enviar estatisticas ao Convex");
}

#endif // TJ_STATS_MQH
