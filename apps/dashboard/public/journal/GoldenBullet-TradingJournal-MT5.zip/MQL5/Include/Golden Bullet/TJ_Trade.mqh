//+------------------------------------------------------------------+
//|  TJ_Trade.mqh — Operar pelo painel (sync, ordens e parciais)     |
//|  Parte do TradingJournal Complete v4.10 (Convex)                 |
//|                                                                  |
//|  O EA não recebe ligações: a cada sync (1 s com o ecrã "Operar"  |
//|  aberto, 15 s no resto do tempo) envia o estado do terminal para |
//|  POST /journal/mt5/sync e recebe as ordens criadas no painel.    |
//|  Cada ordem passa pelos limites deste EA antes de ser executada. |
//|  As parciais automáticas são vigiadas aqui a cada 250 ms.        |
//+------------------------------------------------------------------+
#ifndef TJ_TRADE_MQH
#define TJ_TRADE_MQH

#include <Trade\Trade.mqh>

#define MAX_LEVELS 4

struct PartialPlan
{
    ulong  ticket;       // posição (= ticket da ordem que a abriu)
    bool   be;           // mover o stop para a entrada após a 1.ª parcial
    bool   beDone;
    int    n;
    double price[MAX_LEVELS];
    double volume[MAX_LEVELS];
    bool   done[MAX_LEVELS];
    ulong  nextTry;      // GetTickCount64 da próxima tentativa após falha
};

PartialPlan G_Plans[];
string      G_Watch[];
string      G_SpecsSent[];
string      G_Results[];      // JSON dos resultados ainda não entregues
string      G_DoneIds[];      // comandos já executados (nunca repetir)
ulong       G_NextSync     = 0;
ulong       G_SyncInterval = 15000;
ulong       G_SymbolsSentAt = 0;
ulong       G_SyncFailLogAt = 0;

//====================================================================
//  UTILITÁRIOS
//====================================================================
bool InList(string &list[], string v)
{
    for(int i = ArraySize(list) - 1; i >= 0; i--)
        if(list[i] == v) return true;
    return false;
}

void AddToList(string &list[], string v, int max = 0)
{
    if(InList(list, v)) return;
    int n = ArraySize(list);
    if(max > 0 && n >= max) { ArrayRemove(list, 0, 1); n--; }
    ArrayResize(list, n + 1);
    list[n] = v;
}

bool IsDemoAccount()
{
    return (ENUM_ACCOUNT_TRADE_MODE)AccountInfoInteger(ACCOUNT_TRADE_MODE) == ACCOUNT_TRADE_MODE_DEMO;
}

bool TradingAllowedHere()
{
    return TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) &&
           MQLInfoInteger(MQL_TRADE_ALLOWED) &&
           AccountInfoInteger(ACCOUNT_TRADE_ALLOWED);
}

string Num(double v, int digits) { return DoubleToString(v, digits); }

double NormalizeLot(string symbol, double volume)
{
    double step = SymbolInfoDouble(symbol, SYMBOL_VOLUME_STEP);
    double vmin = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MIN);
    double vmax = SymbolInfoDouble(symbol, SYMBOL_VOLUME_MAX);
    if(step <= 0) step = 0.01;
    double v = MathFloor(volume / step + 1e-9) * step;
    if(v > vmax) v = vmax;
    if(v + 1e-9 < vmin) return 0.0;
    return NormalizeDouble(v, 8);
}

//====================================================================
//  PLANOS DE PARCIAIS (guardados em ficheiro para sobreviver a reinícios)
//====================================================================
void SavePlans()
{
    int h = FileOpen(PLANS_FILE, FILE_WRITE | FILE_TXT | FILE_ANSI);
    if(h == INVALID_HANDLE) return;
    for(int i = 0; i < ArraySize(G_Plans); i++)
    {
        string line = IntegerToString(G_Plans[i].ticket) + ";" +
                      (G_Plans[i].be ? "1" : "0") + ";" +
                      (G_Plans[i].beDone ? "1" : "0") + ";" +
                      IntegerToString(G_Plans[i].n);
        for(int k = 0; k < G_Plans[i].n; k++)
            line += ";" + DoubleToString(G_Plans[i].price[k], 8) + ";" +
                    DoubleToString(G_Plans[i].volume[k], 4) + ";" +
                    (G_Plans[i].done[k] ? "1" : "0");
        FileWriteString(h, line + "\n");
    }
    FileClose(h);
}

void LoadPlans()
{
    ArrayFree(G_Plans);
    if(!FileIsExist(PLANS_FILE)) return;
    int h = FileOpen(PLANS_FILE, FILE_READ | FILE_TXT | FILE_ANSI);
    if(h == INVALID_HANDLE) return;
    while(!FileIsEnding(h))
    {
        string parts[];
        int c = StringSplit(FileReadString(h), ';', parts);
        if(c < 4) continue;
        PartialPlan p;
        ZeroMemory(p);
        p.ticket = (ulong)StringToInteger(parts[0]);
        p.be     = parts[1] == "1";
        p.beDone = parts[2] == "1";
        p.n      = (int)MathMin(MAX_LEVELS, StringToInteger(parts[3]));
        for(int k = 0; k < p.n && 4 + k * 3 + 2 < c; k++)
        {
            p.price[k]  = StringToDouble(parts[4 + k * 3]);
            p.volume[k] = StringToDouble(parts[5 + k * 3]);
            p.done[k]   = parts[6 + k * 3] == "1";
        }
        int n = ArraySize(G_Plans);
        ArrayResize(G_Plans, n + 1);
        G_Plans[n] = p;
    }
    FileClose(h);
    if(ArraySize(G_Plans) > 0)
        PrintFormat("[Trade] %d planos de parciais carregados.", ArraySize(G_Plans));
}

// "1.11800@0.25,1.12000@0.10"
void AddPlan(ulong ticket, string partials, bool be)
{
    if(ticket == 0 || (partials == "" && !be)) return;
    PartialPlan p;
    ZeroMemory(p);
    p.ticket = ticket;
    p.be = be;
    string levels[];
    int c = StringSplit(partials, ',', levels);
    for(int i = 0; i < c && p.n < MAX_LEVELS; i++)
    {
        string pv[];
        if(StringSplit(levels[i], '@', pv) != 2) continue;
        p.price[p.n]  = StringToDouble(pv[0]);
        p.volume[p.n] = StringToDouble(pv[1]);
        p.done[p.n]   = false;
        if(p.price[p.n] > 0 && p.volume[p.n] > 0) p.n++;
    }
    if(p.n == 0) return;   // o breakeven só faz sentido depois de uma parcial
    int n = ArraySize(G_Plans);
    ArrayResize(G_Plans, n + 1);
    G_Plans[n] = p;
    SavePlans();
    PrintFormat("[Trade] Plano de %d parciais na posicao #%I64u%s", p.n, ticket, be ? " (+ breakeven)" : "");
}

// Executa as parciais cujo preço foi atingido (chamado a cada 250 ms).
void CheckPlans()
{
    int n = ArraySize(G_Plans);
    if(n == 0) return;
    bool changed = false;
    CTrade trade;
    trade.SetExpertMagicNumber(InpMagic);
    trade.SetDeviationInPoints(InpSlippagePoints);
    ulong now = GetTickCount64();

    for(int i = n - 1; i >= 0; i--)
    {
        ulong ticket = G_Plans[i].ticket;
        if(!PositionSelectByTicket(ticket))
        {
            // Ordem pendente ainda por executar: o plano espera por ela
            if(OrderSelect(ticket)) continue;
            ArrayRemove(G_Plans, i, 1);
            changed = true;
            continue;
        }
        if(G_Plans[i].nextTry > now) continue;

        string symbol = PositionGetString(POSITION_SYMBOL);
        bool   buy    = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY;
        double open   = PositionGetDouble(POSITION_PRICE_OPEN);
        double sl     = PositionGetDouble(POSITION_SL);
        double tp     = PositionGetDouble(POSITION_TP);
        double vol    = PositionGetDouble(POSITION_VOLUME);
        MqlTick tick;
        if(!SymbolInfoTick(symbol, tick)) continue;
        double price = buy ? tick.bid : tick.ask;   // preço de fecho
        trade.SetTypeFillingBySymbol(symbol);

        bool anyDone = false;
        for(int k = 0; k < G_Plans[i].n; k++)
        {
            if(G_Plans[i].done[k]) { anyDone = true; continue; }
            double level = G_Plans[i].price[k];
            if(buy ? price < level : price > level) continue;
            double close = NormalizeLot(symbol, MathMin(G_Plans[i].volume[k], vol));
            bool ok = close >= vol - 1e-9 ? trade.PositionClose(ticket)
                                          : (close > 0 && trade.PositionClosePartial(ticket, close));
            uint rc = trade.ResultRetcode();
            if(ok && (rc == TRADE_RETCODE_DONE || rc == TRADE_RETCODE_DONE_PARTIAL))
            {
                G_Plans[i].done[k] = true;
                anyDone = true;
                changed = true;
                PrintFormat("[Trade] Parcial %d de #%I64u: %.2f lotes a %s", k + 1, ticket, close,
                            DoubleToString(price, (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS)));
                if(!PositionSelectByTicket(ticket)) break;   // fechou tudo
                vol = PositionGetDouble(POSITION_VOLUME);
            }
            else
            {
                G_Plans[i].nextTry = now + 2000;
                PrintFormat("[Trade] Parcial %d de #%I64u falhou (%u %s)", k + 1, ticket, rc, trade.ResultRetcodeDescription());
                break;
            }
        }

        // Breakeven depois da 1.ª parcial (só se melhorar o stop). O MT5
        // só aceita o stop na entrada quando o preço já passou dela pela
        // distância mínima da corretora: até lá, espera sem tentar.
        if(anyDone && G_Plans[i].be && !G_Plans[i].beDone && PositionSelectByTicket(ticket))
        {
            bool better = buy ? (sl < open - 1e-12) : (sl == 0 || sl > open + 1e-12);
            double minDist = (double)SymbolInfoInteger(symbol, SYMBOL_TRADE_STOPS_LEVEL) *
                             SymbolInfoDouble(symbol, SYMBOL_POINT);
            bool room = buy ? (tick.bid - open > minDist) : (open - tick.ask > minDist);
            if(better && !room) { G_Plans[i].nextTry = now + 500; continue; }
            if(!better || trade.PositionModify(ticket, open, tp))
            {
                G_Plans[i].beDone = true;
                changed = true;
                if(better) PrintFormat("[Trade] #%I64u: stop movido para a entrada (%s)", ticket,
                                       DoubleToString(open, (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS)));
            }
            else G_Plans[i].nextTry = now + 2000;
        }
    }
    if(changed) SavePlans();
}

//====================================================================
//  EXECUÇÃO DOS COMANDOS DO PAINEL
//====================================================================
void PushResult(string id, bool ok, uint retcode, string message,
                ulong ticket = 0, double price = 0, double volume = 0)
{
    string j = "{\"id\":\"" + JE(id) + "\",\"ok\":" + (ok ? "true" : "false") +
               ",\"retcode\":" + IntegerToString(retcode) +
               ",\"message\":\"" + JE(message) + "\"" +
               ",\"ticket\":\"" + IntegerToString(ticket) + "\"" +
               ",\"price\":" + DoubleToString(price, 8) +
               ",\"volume\":" + DoubleToString(volume, 4) + "}";
    int n = ArraySize(G_Results);
    ArrayResize(G_Results, n + 1);
    G_Results[n] = j;
    AddToList(G_DoneIds, id, 500);
    PrintFormat("[Trade] Comando %s: %s", ok ? "executado" : "recusado", message);
}

bool RetOk(uint rc)
{
    return rc == TRADE_RETCODE_DONE || rc == TRADE_RETCODE_DONE_PARTIAL ||
           rc == TRADE_RETCODE_PLACED;
}

// O mesmo controlo de risco do painel, com o cálculo do próprio MT5.
string RiskProblem(string symbol, bool buy, double volume, double entry, double sl)
{
    if(InpMaxLot > 0 && volume > InpMaxLot + 1e-9)
        return StringFormat("Lote %.2f acima do maximo do EA (%.2f).", volume, InpMaxLot);
    if(InpRequireSL && sl <= 0) return "O EA exige stop loss.";
    if(sl <= 0 || InpMaxRiskPct <= 0) return "";
    double profit = 0;
    if(!OrderCalcProfit(buy ? ORDER_TYPE_BUY : ORDER_TYPE_SELL, symbol, volume, entry, sl, profit))
        return "Nao foi possivel calcular o risco da ordem.";
    double balance = AccountInfoDouble(ACCOUNT_BALANCE);
    double pct = balance > 0 ? -profit / balance * 100.0 : 0;
    if(pct > InpMaxRiskPct + 0.05)
        return StringFormat("Risco de %.2f%% acima do maximo do EA (%.2f%%).", pct, InpMaxRiskPct);
    return "";
}

void ExecOpen(string id, string symbol, string side, string type, double volume,
              double price, double sl, double tp, string partials, bool be, string comment)
{
    if(!SymbolSelect(symbol, true)) { PushResult(id, false, 0, "Ativo desconhecido: " + symbol); return; }
    int  digits = (int)SymbolInfoInteger(symbol, SYMBOL_DIGITS);
    bool buy    = side == "buy";
    volume = NormalizeLot(symbol, volume);
    if(volume <= 0) { PushResult(id, false, 0, "Lote abaixo do minimo do ativo."); return; }
    sl = sl > 0 ? NormalizeDouble(sl, digits) : 0;
    tp = tp > 0 ? NormalizeDouble(tp, digits) : 0;

    MqlTick tick;
    SymbolInfoTick(symbol, tick);
    double entry = type == "market" ? (buy ? tick.ask : tick.bid) : NormalizeDouble(price, digits);
    string problem = RiskProblem(symbol, buy, volume, entry, sl);
    if(problem != "") { PushResult(id, false, 0, problem); return; }

    CTrade trade;
    trade.SetExpertMagicNumber(InpMagic);
    trade.SetDeviationInPoints(InpSlippagePoints);
    trade.SetTypeFillingBySymbol(symbol);
    bool sent;
    if(type == "limit")
        sent = buy ? trade.BuyLimit(volume, entry, symbol, sl, tp, ORDER_TIME_GTC, 0, comment)
                   : trade.SellLimit(volume, entry, symbol, sl, tp, ORDER_TIME_GTC, 0, comment);
    else if(type == "stop")
        sent = buy ? trade.BuyStop(volume, entry, symbol, sl, tp, ORDER_TIME_GTC, 0, comment)
                   : trade.SellStop(volume, entry, symbol, sl, tp, ORDER_TIME_GTC, 0, comment);
    else
        sent = buy ? trade.Buy(volume, symbol, 0, sl, tp, comment)
                   : trade.Sell(volume, symbol, 0, sl, tp, comment);

    uint rc = trade.ResultRetcode();
    if(!sent || !RetOk(rc))
    {
        PushResult(id, false, rc, trade.ResultRetcodeDescription());
        return;
    }
    // Ticket da posição (mercado) ou da ordem pendente (vira a posição)
    ulong ticket = trade.ResultOrder();
    ulong deal   = trade.ResultDeal();
    if(type == "market" && deal > 0 && HistoryDealSelect(deal))
        ticket = (ulong)HistoryDealGetInteger(deal, DEAL_POSITION_ID);
    double filled = trade.ResultPrice() > 0 ? trade.ResultPrice() : entry;
    PushResult(id, true, rc, StringFormat("%s %.2f %s a %s", buy ? "Compra" : "Venda", volume, symbol,
                                          DoubleToString(filled, digits)),
               ticket, filled, trade.ResultVolume() > 0 ? trade.ResultVolume() : volume);
    AddPlan(ticket, partials, be);
}

void ExecClose(string id, ulong ticket, double volume)
{
    if(!PositionSelectByTicket(ticket)) { PushResult(id, false, 0, "Posicao nao encontrada (ja fechada?)."); return; }
    string symbol = PositionGetString(POSITION_SYMBOL);
    double vol    = PositionGetDouble(POSITION_VOLUME);
    CTrade trade;
    trade.SetExpertMagicNumber(InpMagic);
    trade.SetDeviationInPoints(InpSlippagePoints);
    trade.SetTypeFillingBySymbol(symbol);
    double close = volume > 0 ? NormalizeLot(symbol, MathMin(volume, vol)) : vol;
    if(close <= 0) { PushResult(id, false, 0, "Volume parcial abaixo do minimo do ativo."); return; }
    bool ok = close >= vol - 1e-9 ? trade.PositionClose(ticket)
                                  : trade.PositionClosePartial(ticket, close);
    uint rc = trade.ResultRetcode();
    if(ok && RetOk(rc))
        PushResult(id, true, rc, StringFormat("Fechados %.2f de #%I64u", close, ticket),
                   ticket, trade.ResultPrice(), close);
    else
        PushResult(id, false, rc, trade.ResultRetcodeDescription());
}

void ExecModify(string id, ulong ticket, double sl, double tp)
{
    if(InpRequireSL && sl <= 0) { PushResult(id, false, 0, "O EA exige stop loss."); return; }
    CTrade trade;
    trade.SetExpertMagicNumber(InpMagic);
    bool ok;
    int  digits;
    if(PositionSelectByTicket(ticket))
    {
        digits = (int)SymbolInfoInteger(PositionGetString(POSITION_SYMBOL), SYMBOL_DIGITS);
        ok = trade.PositionModify(ticket, NormalizeDouble(sl, digits), NormalizeDouble(tp, digits));
    }
    else if(OrderSelect(ticket))
    {
        digits = (int)SymbolInfoInteger(OrderGetString(ORDER_SYMBOL), SYMBOL_DIGITS);
        ok = trade.OrderModify(ticket, OrderGetDouble(ORDER_PRICE_OPEN), NormalizeDouble(sl, digits),
                               NormalizeDouble(tp, digits), ORDER_TIME_GTC, 0);
    }
    else { PushResult(id, false, 0, "Posicao ou ordem nao encontrada."); return; }
    uint rc = trade.ResultRetcode();
    if(ok && RetOk(rc)) PushResult(id, true, rc, StringFormat("SL/TP de #%I64u alterados", ticket), ticket);
    else PushResult(id, false, rc, trade.ResultRetcodeDescription());
}

void ExecCancel(string id, ulong ticket)
{
    if(!OrderSelect(ticket)) { PushResult(id, false, 0, "Ordem pendente nao encontrada."); return; }
    CTrade trade;
    bool ok = trade.OrderDelete(ticket);
    uint rc = trade.ResultRetcode();
    if(ok && RetOk(rc)) PushResult(id, true, rc, StringFormat("Ordem #%I64u cancelada", ticket), ticket);
    else PushResult(id, false, rc, trade.ResultRetcodeDescription());
}

// cmd=<id>\t<kind>\t<symbol>\t<side>\t<type>\t<volume>\t<price>\t<sl>\t<tp>\t<ticket>\t<age_ms>\t<partials>\t<be>\t<comment>
void RunCommand(string line)
{
    string f[];
    if(StringSplit(line, '\t', f) < 14) return;
    string id = f[0];
    if(id == "" || InList(G_DoneIds, id)) return;

    if(StringToInteger(f[10]) > (long)InpCommandMaxAgeSec * 1000)
        { PushResult(id, false, 0, "Ordem expirou antes de chegar ao MT5."); return; }
    if(!InpAllowTrading)
        { PushResult(id, false, 0, "O EA nao aceita ordens do painel (InpAllowTrading=false)."); return; }
    if(InpDemoOnly && !IsDemoAccount())
        { PushResult(id, false, 0, "O EA esta em modo so demo (InpDemoOnly)."); return; }
    if(!TradingAllowedHere())
        { PushResult(id, false, 0, "Algo Trading desligado no MT5."); return; }

    string kind = f[1];
    ulong ticket = (ulong)StringToInteger(f[9]);
    if(kind == "open")
        ExecOpen(id, f[2], f[3], f[4], StringToDouble(f[5]), StringToDouble(f[6]),
                 StringToDouble(f[7]), StringToDouble(f[8]), f[11], f[12] == "1", f[13]);
    else if(kind == "close")  ExecClose(id, ticket, StringToDouble(f[5]));
    else if(kind == "modify") ExecModify(id, ticket, StringToDouble(f[7]), StringToDouble(f[8]));
    else if(kind == "cancel") ExecCancel(id, ticket);
    else PushResult(id, false, 0, "Comando desconhecido: " + kind);
}

//====================================================================
//  SYNC
//====================================================================
string PendingTypeName(ENUM_ORDER_TYPE t)
{
    switch(t)
    {
        case ORDER_TYPE_BUY_LIMIT:  return "buy_limit";
        case ORDER_TYPE_SELL_LIMIT: return "sell_limit";
        case ORDER_TYPE_BUY_STOP:   return "buy_stop";
        case ORDER_TYPE_SELL_STOP:  return "sell_stop";
    }
    return "";
}

string PositionsJson(string &symbols[])
{
    string j = "[";
    for(int i = 0; i < PositionsTotal(); i++)
    {
        ulong t = PositionGetTicket(i);
        if(t == 0) continue;
        string sym = PositionGetString(POSITION_SYMBOL);
        AddToList(symbols, sym);
        int d = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
        if(j != "[") j += ",";
        j += "{\"ticket\":\"" + IntegerToString(t) + "\",\"symbol\":\"" + JE(sym) + "\"" +
             ",\"type\":\"" + ((ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY ? "buy" : "sell") + "\"" +
             ",\"volume\":" + Num(PositionGetDouble(POSITION_VOLUME), 2) +
             ",\"price_open\":" + Num(PositionGetDouble(POSITION_PRICE_OPEN), d) +
             ",\"price_current\":" + Num(PositionGetDouble(POSITION_PRICE_CURRENT), d) +
             ",\"sl\":" + Num(PositionGetDouble(POSITION_SL), d) +
             ",\"tp\":" + Num(PositionGetDouble(POSITION_TP), d) +
             ",\"profit\":" + Num(PositionGetDouble(POSITION_PROFIT), 2) +
             ",\"swap\":" + Num(PositionGetDouble(POSITION_SWAP), 2) +
             ",\"time_msc\":" + IntegerToString(PositionGetInteger(POSITION_TIME_MSC)) +
             ",\"magic\":" + IntegerToString(PositionGetInteger(POSITION_MAGIC)) +
             ",\"comment\":\"" + JE(PositionGetString(POSITION_COMMENT)) + "\"}";
    }
    return j + "]";
}

string OrdersJson()
{
    string j = "[";
    for(int i = 0; i < OrdersTotal(); i++)
    {
        ulong t = OrderGetTicket(i);
        if(t == 0) continue;
        string type = PendingTypeName((ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE));
        if(type == "") continue;
        string sym = OrderGetString(ORDER_SYMBOL);
        int d = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
        if(j != "[") j += ",";
        j += "{\"ticket\":\"" + IntegerToString(t) + "\",\"symbol\":\"" + JE(sym) + "\"" +
             ",\"type\":\"" + type + "\"" +
             ",\"volume\":" + Num(OrderGetDouble(ORDER_VOLUME_CURRENT), 2) +
             ",\"price\":" + Num(OrderGetDouble(ORDER_PRICE_OPEN), d) +
             ",\"sl\":" + Num(OrderGetDouble(ORDER_SL), d) +
             ",\"tp\":" + Num(OrderGetDouble(ORDER_TP), d) +
             ",\"time_msc\":" + IntegerToString(OrderGetInteger(ORDER_TIME_SETUP_MSC)) + "}";
    }
    return j + "]";
}

string QuotesJson(string &symbols[])
{
    string j = "[";
    for(int i = 0; i < ArraySize(symbols); i++)
    {
        string sym = symbols[i];
        if(!SymbolSelect(sym, true)) continue;
        MqlTick tick;
        if(!SymbolInfoTick(sym, tick) || tick.bid <= 0) continue;
        int d = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
        double tv = SymbolInfoDouble(sym, SYMBOL_TRADE_TICK_VALUE_LOSS);
        if(tv <= 0) tv = SymbolInfoDouble(sym, SYMBOL_TRADE_TICK_VALUE);
        double mb = 0, ms = 0;
        // Sem cálculo de margem (mercado fechado…): o painel mostra "—"
        if(!OrderCalcMargin(ORDER_TYPE_BUY, sym, 1.0, tick.ask, mb)) mb = 0;
        if(!OrderCalcMargin(ORDER_TYPE_SELL, sym, 1.0, tick.bid, ms)) ms = 0;
        if(j != "[") j += ",";
        j += "{\"symbol\":\"" + JE(sym) + "\",\"bid\":" + Num(tick.bid, d) + ",\"ask\":" + Num(tick.ask, d) +
             ",\"spread\":" + IntegerToString(SymbolInfoInteger(sym, SYMBOL_SPREAD)) +
             ",\"tick_value\":" + Num(tv, 8) +
             ",\"margin_buy\":" + Num(mb, 2) + ",\"margin_sell\":" + Num(ms, 2) +
             ",\"time_msc\":" + IntegerToString(tick.time_msc) + "}";
    }
    return j + "]";
}

// Especificações dos símbolos vigiados que o painel ainda não tem.
string SpecsJson(string &symbols[], string &sending[])
{
    string j = "[";
    for(int i = 0; i < ArraySize(symbols); i++)
    {
        string sym = symbols[i];
        if(InList(G_SpecsSent, sym) || !SymbolSelect(sym, true)) continue;
        double tv = SymbolInfoDouble(sym, SYMBOL_TRADE_TICK_VALUE_LOSS);
        if(tv <= 0) tv = SymbolInfoDouble(sym, SYMBOL_TRADE_TICK_VALUE);
        if(j != "[") j += ",";
        j += "{\"symbol\":\"" + JE(sym) + "\"" +
             ",\"digits\":" + IntegerToString(SymbolInfoInteger(sym, SYMBOL_DIGITS)) +
             ",\"point\":" + Num(SymbolInfoDouble(sym, SYMBOL_POINT), 10) +
             ",\"tick_size\":" + Num(SymbolInfoDouble(sym, SYMBOL_TRADE_TICK_SIZE), 10) +
             ",\"tick_value\":" + Num(tv, 8) +
             ",\"contract_size\":" + Num(SymbolInfoDouble(sym, SYMBOL_TRADE_CONTRACT_SIZE), 4) +
             ",\"volume_min\":" + Num(SymbolInfoDouble(sym, SYMBOL_VOLUME_MIN), 4) +
             ",\"volume_max\":" + Num(SymbolInfoDouble(sym, SYMBOL_VOLUME_MAX), 4) +
             ",\"volume_step\":" + Num(SymbolInfoDouble(sym, SYMBOL_VOLUME_STEP), 4) +
             ",\"stops_level\":" + IntegerToString(SymbolInfoInteger(sym, SYMBOL_TRADE_STOPS_LEVEL)) + "}";
        AddToList(sending, sym);
    }
    return j + "]";
}

string MarketWatchJson()
{
    string j = "[";
    int n = SymbolsTotal(true);
    for(int i = 0; i < n && i < 2000; i++)
    {
        if(j != "[") j += ",";
        j += "\"" + JE(SymbolName(i, true)) + "\"";
    }
    return j + "]";
}

string PlansJson()
{
    string j = "[";
    for(int i = 0; i < ArraySize(G_Plans); i++)
    {
        if(j != "[") j += ",";
        j += "{\"ticket\":\"" + IntegerToString(G_Plans[i].ticket) + "\",\"be\":" +
             (G_Plans[i].be ? "true" : "false") + ",\"levels\":[";
        for(int k = 0; k < G_Plans[i].n; k++)
        {
            if(k > 0) j += ",";
            j += "{\"price\":" + DoubleToString(G_Plans[i].price[k], 8) +
                 ",\"volume\":" + DoubleToString(G_Plans[i].volume[k], 4) +
                 ",\"done\":" + (G_Plans[i].done[k] ? "true" : "false") + "}";
        }
        j += "]}";
    }
    return j + "]";
}

string SyncBody(string &sendingSpecs[], int &resultsSent, bool withSymbols)
{
    string symbols[];
    ArrayCopy(symbols, G_Watch);
    string positions = PositionsJson(symbols);   // junta os símbolos das posições

    string b = "{";
    b += "\"account\":\"" + IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN)) + "\",";
    b += "\"server\":\"" + JE(AccountInfoString(ACCOUNT_SERVER)) + "\",";
    b += "\"server_offset_sec\":" + IntegerToString(ServerOffsetSec()) + ",";
    b += "\"info\":{\"balance\":" + Num(AccountInfoDouble(ACCOUNT_BALANCE), 2) +
         ",\"equity\":" + Num(AccountInfoDouble(ACCOUNT_EQUITY), 2) +
         ",\"margin\":" + Num(AccountInfoDouble(ACCOUNT_MARGIN), 2) +
         ",\"free_margin\":" + Num(AccountInfoDouble(ACCOUNT_MARGIN_FREE), 2) +
         ",\"leverage\":" + IntegerToString(AccountInfoInteger(ACCOUNT_LEVERAGE)) +
         ",\"currency\":\"" + JE(AccountInfoString(ACCOUNT_CURRENCY)) + "\"" +
         ",\"trade_allowed\":" + (TradingAllowedHere() ? "true" : "false") +
         ",\"demo\":" + (IsDemoAccount() ? "true" : "false") + "},";
    b += "\"limits\":{\"allow_trading\":" + (InpAllowTrading ? "true" : "false") +
         ",\"max_lot\":" + Num(InpMaxLot, 2) +
         ",\"max_risk_pct\":" + Num(InpMaxRiskPct, 2) +
         ",\"demo_only\":" + (InpDemoOnly ? "true" : "false") +
         ",\"require_sl\":" + (InpRequireSL ? "true" : "false") + "},";
    b += "\"positions\":" + positions + ",";
    b += "\"orders\":" + OrdersJson() + ",";
    b += "\"quotes\":" + QuotesJson(symbols) + ",";
    b += "\"specs\":" + SpecsJson(symbols, sendingSpecs) + ",";
    if(withSymbols) b += "\"symbols\":" + MarketWatchJson() + ",";
    b += "\"plans\":" + PlansJson() + ",";
    resultsSent = ArraySize(G_Results);
    b += "\"results\":[";
    for(int i = 0; i < resultsSent; i++)
    {
        if(i > 0) b += ",";
        b += G_Results[i];
    }
    b += "]}";
    return b;
}

void ParseSyncResponse(string resp)
{
    string lines[];
    int n = StringSplit(resp, '\n', lines);
    for(int i = 0; i < n; i++)
    {
        string l = lines[i];
        if(StringFind(l, "next_ms=") == 0)
        {
            long ms = StringToInteger(StringSubstr(l, 8));
            G_SyncInterval = (ulong)MathMax(500, MathMin(60000, ms));
        }
        else if(StringFind(l, "watch=") == 0)
        {
            ArrayFree(G_Watch);
            string w = StringSubstr(l, 6);
            if(w != "") StringSplit(w, ',', G_Watch);
        }
        else if(StringFind(l, "cmd=") == 0)
            RunCommand(StringSubstr(l, 4));
    }
}

void RunTradeSync()
{
    ulong now = GetTickCount64();
    if(now < G_NextSync) return;

    bool withSymbols = G_SymbolsSentAt == 0 || now - G_SymbolsSentAt > 300000;
    string sending[];
    int resultsSent = 0;
    string body = SyncBody(sending, resultsSent, withSymbols);
    string resp = ConvexPost(SYNC_PATH, body, false, 5000);
    if(resp == "")
    {
        G_NextSync = GetTickCount64() + MathMax(G_SyncInterval, 5000);
        if(now - G_SyncFailLogAt > 60000)
        {
            Print("[Trade] Sync com o painel falhou (o painel atual pode nao ter a rota /journal/mt5/sync). Nova tentativa em breve.");
            G_SyncFailLogAt = now;
        }
        return;
    }
    // Entregues: limpa os resultados enviados e marca as especificações
    if(resultsSent > 0) ArrayRemove(G_Results, 0, resultsSent);
    for(int i = 0; i < ArraySize(sending); i++) AddToList(G_SpecsSent, sending[i]);
    if(withSymbols) G_SymbolsSentAt = now;

    int before = ArraySize(G_Results);
    ParseSyncResponse(resp);
    // Comando executado agora: entrega o resultado já no próximo segundo
    G_NextSync = GetTickCount64() + (ArraySize(G_Results) > before ? 300 : G_SyncInterval);
}

void InitTrade()
{
    LoadPlans();
    G_NextSync = 0;
    PrintFormat("[Trade] Operar pelo painel: %s | lote max %.2f | risco max %.2f%% | %s",
                InpAllowTrading ? "ATIVO" : "desligado (so leitura)", InpMaxLot, InpMaxRiskPct,
                InpDemoOnly ? "so demo" : "demo e real");
}

#endif // TJ_TRADE_MQH
