//+------------------------------------------------------------------+
//|                                        TradingJournalStats.mqh   |
//|                                Copyright 2024, JR369 HOLDINGS    |
//|                    Versão Otimizada para Electron Bridge         |
//+------------------------------------------------------------------+
#ifndef TRADINGJOURNALSTATS_MQH
#define TRADINGJOURNALSTATS_MQH

#include <Trade\DealInfo.mqh>

struct SAccountStats
{
    string accountName, companyName, serverName, currency, accountNumber;
    double balance, equity, freeMargin, initialDeposit, withdrawal;
    double grossProfit, grossLoss, netProfit, dailyProfit, weeklyProfit, monthlyProfit;
    double totalCommission, totalSwap;
    double maxProfitTrade, maxLossTrade;
    int    totalTrades, profitTrades, lossTrades, longTrades, shortTrades;
    int    maxConWins, maxConLosses, maxConProfitTrades;
    double winRate, profitFactor, recoveryFactor, sharpeRatio, expectedPayoff, dailyDrawdown;
    double startingWeeklyEquity, startingMonthlyEquity;
    double weeklyTarget, monthlyTarget;
    double weeklyTargetProgress, monthlyTargetProgress, targetPercent;
};

//--- Localizadores de Depósito Inicial
double Stats_FindInitialDeposit()
{
    if(!HistorySelect(0, TimeCurrent())) return AccountInfoDouble(ACCOUNT_BALANCE);
    int total = HistoryDealsTotal();
    for(int i = 0; i < total; i++)
    {
        ulong ticket = HistoryDealGetTicket(i);
        if(ticket == 0) continue;
        if((ENUM_DEAL_TYPE)HistoryDealGetInteger(ticket, DEAL_TYPE) == DEAL_TYPE_BALANCE)
        {
            double amount = HistoryDealGetDouble(ticket, DEAL_PROFIT);
            if(amount > 0.0) return amount;
        }
    }
    return AccountInfoDouble(ACCOUNT_BALANCE);
}

//--- Cálculo de PnL por Período
double Stats_CalcPeriodPnL(datetime from, datetime to)
{
    if(!HistorySelect(from, to)) return 0.0;
    double pnl = 0.0;
    int total  = HistoryDealsTotal();
    for(int i = 0; i < total; i++)
    {
        ulong ticket = HistoryDealGetTicket(i);
        if(ticket == 0) continue;
        ENUM_DEAL_ENTRY entry = (ENUM_DEAL_ENTRY)HistoryDealGetInteger(ticket, DEAL_ENTRY);
        if(entry != DEAL_ENTRY_OUT && entry != DEAL_ENTRY_INOUT) continue;
        ENUM_DEAL_TYPE dtype = (ENUM_DEAL_TYPE)HistoryDealGetInteger(ticket, DEAL_TYPE);
        if(dtype != DEAL_TYPE_BUY && dtype != DEAL_TYPE_SELL) continue;
        pnl += HistoryDealGetDouble(ticket, DEAL_PROFIT)
             + HistoryDealGetDouble(ticket, DEAL_COMMISSION)
             + HistoryDealGetDouble(ticket, DEAL_SWAP);
    }
    return NormalizeDouble(pnl, 2);
}

double Stats_GetDailyProfit()
{
    MqlDateTime dt; TimeToStruct(TimeCurrent(), dt);
    dt.hour = 0; dt.min = 0; dt.sec = 0;
    datetime startDay = StructToTime(dt);
    return Stats_CalcPeriodPnL(startDay, TimeCurrent());
}

double Stats_GetWeeklyProfit()
{
    MqlDateTime dt; TimeToStruct(TimeCurrent(), dt);
    int sub = dt.day_of_week - 1; if(sub < 0) sub += 7;
    datetime startWeek = TimeCurrent() - sub * 86400;
    MqlDateTime sw; TimeToStruct(startWeek, sw);
    sw.hour = 0; sw.min = 0; sw.sec = 0;
    return Stats_CalcPeriodPnL(StructToTime(sw), TimeCurrent());
}

double Stats_GetMonthlyProfit()
{
    MqlDateTime dt; TimeToStruct(TimeCurrent(), dt);
    dt.day = 1; dt.hour = 0; dt.min = 0; dt.sec = 0;
    return Stats_CalcPeriodPnL(StructToTime(dt), TimeCurrent());
}

//--- O CORAÇÃO DO QUANT ENGINE: Calcula todas as métricas
bool Stats_Calculate(SAccountStats &s, double inputTargetPct,
                     double inputWeeklyTarget, double inputMonthlyTarget)
{
    s.accountName   = AccountInfoString(ACCOUNT_NAME);
    s.companyName   = AccountInfoString(ACCOUNT_COMPANY);
    s.serverName    = AccountInfoString(ACCOUNT_SERVER);
    s.currency      = AccountInfoString(ACCOUNT_CURRENCY);
    s.accountNumber = IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN));
    s.balance       = AccountInfoDouble(ACCOUNT_BALANCE);
    s.equity        = AccountInfoDouble(ACCOUNT_EQUITY);
    s.freeMargin    = AccountInfoDouble(ACCOUNT_MARGIN_FREE);
    s.targetPercent = inputTargetPct / 100.0;
    s.initialDeposit= Stats_FindInitialDeposit();
    s.dailyProfit   = Stats_GetDailyProfit();
    s.weeklyProfit  = Stats_GetWeeklyProfit();
    s.monthlyProfit = Stats_GetMonthlyProfit();
    s.startingWeeklyEquity  = s.equity - s.weeklyProfit;
    s.startingMonthlyEquity = s.equity - s.monthlyProfit;
    s.weeklyTarget  = inputWeeklyTarget;
    s.monthlyTarget = inputMonthlyTarget;

    if(s.weeklyTarget  > 0.0) s.weeklyTargetProgress  = MathMax(0.0, MathMin(1.0, s.weeklyProfit  / s.weeklyTarget));
    else                       s.weeklyTargetProgress  = 0.0;
    if(s.monthlyTarget > 0.0) s.monthlyTargetProgress = MathMax(0.0, MathMin(1.0, s.monthlyProfit / s.monthlyTarget));
    else                       s.monthlyTargetProgress = 0.0;

    if(!HistorySelect(0, TimeCurrent())) return false;
    int totalDeals = HistoryDealsTotal();
    double grossProfit=0, grossLoss=0, totalComm=0, totalSwap=0, withdrawal=0;
    int trades=0, wins=0, losses=0, longTrades=0, shortTrades=0;
    double maxProfit=0, maxLoss=0;

    double balanceCurve[]; ArrayResize(balanceCurve, 0);
    double runBalance = s.initialDeposit;
    int conWins=0, conLosses=0, maxConW=0, maxConL=0, conPT=0, maxConPT=0;
    double rets[]; ArrayResize(rets, 0);   // retorno de cada trade sobre o saldo anterior (Sharpe)

    for(int i = 0; i < totalDeals; i++)
    {
        ulong ticket = HistoryDealGetTicket(i);
        if(ticket == 0) continue;
        ENUM_DEAL_TYPE  dtype = (ENUM_DEAL_TYPE) HistoryDealGetInteger(ticket, DEAL_TYPE);
        ENUM_DEAL_ENTRY entry = (ENUM_DEAL_ENTRY)HistoryDealGetInteger(ticket, DEAL_ENTRY);

        if(dtype == DEAL_TYPE_BALANCE)
        {
            double bal = HistoryDealGetDouble(ticket, DEAL_PROFIT);
            if(bal < 0.0) withdrawal += MathAbs(bal);
            runBalance += bal;
            continue;
        }

        if(dtype != DEAL_TYPE_BUY && dtype != DEAL_TYPE_SELL) continue;
        if(entry != DEAL_ENTRY_OUT && entry != DEAL_ENTRY_INOUT) continue;

        double profit = HistoryDealGetDouble(ticket, DEAL_PROFIT);
        double comm   = HistoryDealGetDouble(ticket, DEAL_COMMISSION);
        double swap   = HistoryDealGetDouble(ticket, DEAL_SWAP);
        double net    = NormalizeDouble(profit + comm + swap, 2);

        totalComm += comm; totalSwap += swap; trades++;
        if(runBalance > 0.0)
        {
            int rn = ArraySize(rets); ArrayResize(rets, rn+1); rets[rn] = net / runBalance;
        }
        runBalance += net;

        int bn = ArraySize(balanceCurve); ArrayResize(balanceCurve, bn+1); balanceCurve[bn] = runBalance;

        if(net >= 0.0)
        {
            grossProfit += net; wins++;
            if(net > maxProfit) maxProfit = net;
            conLosses = 0;
            conWins++; conPT++;
            if(conWins > maxConW) maxConW = conWins;
            if(conPT > maxConPT) maxConPT = conPT;
        }
        else
        {
            grossLoss += net; losses++;
            if(net < maxLoss) maxLoss = net;
            conWins = 0; conPT = 0;
            conLosses++; if(conLosses > maxConL) maxConL = conLosses;
        }
        if(dtype == DEAL_TYPE_BUY) shortTrades++; else longTrades++;
    }

    s.grossProfit=grossProfit; s.grossLoss=grossLoss;
    s.netProfit=NormalizeDouble(grossProfit+grossLoss,2);
    s.totalCommission=totalComm; s.totalSwap=totalSwap;
    s.withdrawal=withdrawal; s.totalTrades=trades;
    s.profitTrades=wins; s.lossTrades=losses;
    s.longTrades=longTrades; s.shortTrades=shortTrades;
    s.maxProfitTrade=maxProfit; s.maxLossTrade=maxLoss;
    s.maxConWins=maxConW; s.maxConLosses=maxConL; s.maxConProfitTrades=maxConPT;
    s.winRate=(trades>0)?(double)wins/trades:0.0;
    s.profitFactor=(MathAbs(grossLoss)>0.0001)?MathAbs(grossProfit/grossLoss):0.0;
    s.expectedPayoff=(trades>0)?s.netProfit/trades:0.0;

    double startBal=s.balance-s.dailyProfit;
    s.dailyDrawdown=(startBal>0.0)?(s.dailyProfit/startBal):0.0;

    int bLen=ArraySize(balanceCurve);
    if(bLen>1)
    {
        double maxPeak=balanceCurve[0], maxDD=0.0;
        for(int i=1;i<bLen;i++){
            if(balanceCurve[i]>maxPeak) maxPeak=balanceCurve[i];
            double dd=maxPeak-balanceCurve[i];
            if(dd>maxDD) maxDD=dd;
        }
        s.recoveryFactor=(maxDD>0.0001)?s.netProfit/maxDD:0.0;
    }
    else s.recoveryFactor=0.0;

    // Sharpe por trade (sem anualizar): média / desvio-padrão dos retornos
    s.sharpeRatio=0.0;
    int rLen=ArraySize(rets);
    if(rLen>1)
    {
        double mean=0.0; for(int i=0;i<rLen;i++) mean+=rets[i]; mean/=rLen;
        double var=0.0;  for(int i=0;i<rLen;i++) var+=(rets[i]-mean)*(rets[i]-mean);
        double sd=MathSqrt(var/(rLen-1));
        if(sd>1e-12) s.sharpeRatio=mean/sd;
    }

    return true;
}

// Stub mantido para compatibilidade — a implementação real fica no .mq5 (RunStatsSync)
bool Stats_SyncAfterExport(string statsDS_ID, string mainDS_ID, string tradePageID,
                            double inputTargetPct, double weeklyTarget, double monthlyTarget)
{
    return true;
}

#endif